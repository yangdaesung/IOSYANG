//
//  ViewController.m
//  Project
//
//  Created by Yang on 2016. 10. 29..
//  Copyright © 2016년 Yang. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()<UIScrollViewDelegate>
@property (nonatomic)UIScrollView *scroll;
@property (nonatomic)NSArray *Blackpink;
@property (nonatomic, strong) NSArray *dataSource;


@property(nonatomic, retain) IBOutlet UIScrollView *scrollView;
@property(nonatomic, retain) IBOutlet UIPageControl *pageControl;

@end

@implementation ViewController

static NSString* const CellIdentifier = @"DynamicTableViewCell";

- (void)viewDidLoad {
    [super viewDidLoad];
  
    self.dataSource = @[@"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum    has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
                        @"Lorem Ipsum is simply dummy text",
                        @"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                        @"Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.",
                        @"There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc."
                        ];

    
    self.Blackpink = @[@{@"name":@"블랙핑크",@"image":@"블랙핑크2.jpeg"},
                       @{@"name":@"블랙핑크",@"image":@"블랙핑크3.jpeg"},
                       @{@"name":@"블랙핑크",@"image":@"블랙핑크4.jpeg"},
                       @{@"name":@"블랙핑크",@"image":@"블랙핑크5.jpeg"},
                       @{@"name":@"제니",@"image":@"제니.jpeg"},
                       @{@"name":@"지수",@"image":@"지수.jpg"},
                       @{@"name":@"블랙핑크",@"image":@"블랙핑크1.jpeg"}];
    
    

    //이미지 불러오기
    NSUInteger i = 0;
    NSMutableArray *thisImg = [[NSMutableArray alloc] init];
    
    for(NSDictionary *songName in self.Blackpink){
        [thisImg addObject:[songName objectForKey:@"image"]];
    }
    i = thisImg.count;
    [self.scrollView setContentSize:CGSizeMake(self.scrollView.frame.size.width * i, self.scrollView.frame.size.height)];
    
    for (NSInteger i = 0 ; i < thisImg.count; i += 1) {
        UIImage *img = [[UIImage alloc] init];
        img = [UIImage imageNamed:[thisImg objectAtIndex:i]];
        
        UIImageView *imgView = [[UIImageView alloc] init];
        imgView.frame = CGRectMake(self.scrollView.frame.size.width*i, 0, self.scrollView.frame.size.width, self.scrollView.frame.size.height);
        
        imgView.contentMode = UIViewContentModeScaleToFill;
        [imgView setImage:img];
        [self.scrollView addSubview:imgView];
        if(i == 0){
            NSLog(@"이미지");
            
        }
    }
    //ScrollView에 필요한 옵션을 적용한다.
    
    
    //vertical = 세로 , Horizontal = 가로 스크롤효과를 적용.
    self.scrollView.showsVerticalScrollIndicator=NO;
    self.scrollView.showsHorizontalScrollIndicator=YES;
    // 스크롤이 경계에 도달하면 바운싱효과를 적용
    self.scrollView.alwaysBounceVertical=NO;
    self.scrollView.alwaysBounceHorizontal=YES;
    //페이징 가능 여부 YES
    self.scrollView.pagingEnabled=YES;
    self.scrollView.delegate=self;
    //pageControl에 필요한 옵션을 적용한다.
    //현재 페이지 index는 0
    self.pageControl.currentPage =0;
    //페이지 갯수
    self.pageControl.numberOfPages=self.Blackpink.count;
     //페이지 컨트롤 값변경시 이벤트 처리 등록
    [self.pageControl addTarget:self action:@selector(pageChangeValue:) forControlEvents:UIControlEventValueChanged];
    
    [self.view addSubview:self.pageControl];
}

//스크롤이 변경될때 page의 currentPage 설정
- (void)scrollViewDidScroll:(UIScrollView *)sender {
//    CGFloat pageWidth = self.scrollView.frame.size.width;
//    self.pageControl.currentPage = floor((self.scrollView.contentOffset.x - pageWidth / 3) / pageWidth) + 1;
    self.pageControl.currentPage = self.scrollView.contentOffset.x/self.scrollView.frame.size.width;
}
//페이지 컨트롤 값이 변경될때, 스크롤뷰 위치 설정
- (void) pageChangeValue:(id)sender {
    UIPageControl *pControl = (UIPageControl *) sender;
    [self.scrollView setContentOffset:CGPointMake(pControl.currentPage*320, 0) animated:YES];
}
 // 스크롤바를 보였다가 사라지게 함
- (void)viewDidAppear:(BOOL)animated
{
    [self.scrollView flashScrollIndicators];
}

- (void)didReceiveMemoryWarning {

    [super didReceiveMemoryWarning];
    
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}



@end
