//
//  ItemView.h
//  VendingMachine
//
//  Created by youngmin joo on 2016. 10. 11..
//  Copyright © 2016년 WingsCompany. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol ItemViewDelegate;

@interface ItemView : UIView

@property (nonatomic, weak) id <ItemViewDelegate> delegate;
- (instancetype)initWithData:(NSDictionary *)data;

- (NSInteger)getCost;
- (NSString *)getTitle;

@end


@protocol ItemViewDelegate <NSObject>

- (void)didSelectedItemView:(ItemView *)itemView;

@end

